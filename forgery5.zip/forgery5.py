import cv2
import hashlib
import os
import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

class ImageForgeryDetectorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Forgery Detector")

        self.original_image_path = tk.StringVar()
        self.tampered_image_path = tk.StringVar()
        self.ssim_threshold = tk.DoubleVar(value=0.9)

        # Create widgets
        tk.Label(root, text="Original Image:").grid(row=0, column=0)
        tk.Entry(root, textvariable=self.original_image_path, state="readonly").grid(row=0, column=1)
        tk.Button(root, text="Browse", command=self.browse_original).grid(row=0, column=2)

        tk.Label(root, text="Tampered Image:").grid(row=1, column=0)
        tk.Entry(root, textvariable=self.tampered_image_path, state="readonly").grid(row=1, column=1)
        tk.Button(root, text="Browse", command=self.browse_tampered).grid(row=1, column=2)

        tk.Label(root, text="SSIM Threshold:").grid(row=2, column=0)
        tk.Scale(root, variable=self.ssim_threshold, from_=0, to=1, resolution=0.01, orient=tk.HORIZONTAL).grid(row=2, column=1)

        tk.Button(root, text="Detect Forgery", command=self.detect_forgery).grid(row=3, column=1)
        tk.Button(root, text="Show Histograms", command=self.show_histograms).grid(row=4, column=1)
        tk.Button(root, text="Save Histograms", command=self.save_histograms).grid(row=5, column=1)

        # Result Text Widget
        self.result_text = tk.Text(root, height=10, width=50)
        self.result_text.grid(row=6, column=0, columnspan=3)

        # Image Previews
        self.original_image_preview = tk.Label(root, text="Original Image Preview")
        self.original_image_preview.grid(row=7, column=0)

        self.tampered_image_preview = tk.Label(root, text="Tampered Image Preview")
        self.tampered_image_preview.grid(row=7, column=1)

        # Create figure instances for histograms
        self.original_histogram_figure = plt.Figure()
        self.tampered_histogram_figure = plt.Figure()

    def browse_original(self):
        file_path = filedialog.askopenfilename(title="Select Original Image")
        if file_path:
            self.original_image_path.set(file_path)
            self.display_image_preview(file_path, self.original_image_preview)

    def browse_tampered(self):
        file_path = filedialog.askopenfilename(title="Select Tampered Image")
        if file_path:
            self.tampered_image_path.set(file_path)
            self.display_image_preview(file_path, self.tampered_image_preview)

    def detect_forgery(self):
        original_path = self.original_image_path.get()
        tampered_path = self.tampered_image_path.get()

        if not os.path.exists(original_path) or not os.path.exists(tampered_path):
            messagebox.showerror("Error", "Image file not found.")
            return

        # Call the detect_image_forgery function with the provided paths
        result, original_histogram, tampered_histogram = detect_image_forgery(original_path, tampered_path, self.ssim_threshold.get())

        # Display the results in the GUI
        self.result_text.delete(1.0, tk.END)  # Clear previous results
        self.result_text.insert(tk.END, result)

        # Display histograms
        self.display_histogram(original_histogram, self.original_histogram_figure, "Original Image Histogram", "Blue", 0)
        self.display_histogram(tampered_histogram, self.tampered_histogram_figure, "Tampered Image Histogram", "Red", 1)

    def show_histograms(self):
        original_path = self.original_image_path.get()
        tampered_path = self.tampered_image_path.get()

        if not os.path.exists(original_path) or not os.path.exists(tampered_path):
            messagebox.showerror("Error", "Image file not found.")
            return

        # Display histograms for both images
        _, original_histogram, tampered_histogram = detect_image_forgery(original_path, tampered_path, self.ssim_threshold.get())
        self.display_histogram(original_histogram, self.original_histogram_figure, "Original Image Histogram", "Blue", 0)
        self.display_histogram(tampered_histogram, self.tampered_histogram_figure, "Tampered Image Histogram", "Red", 1)

    def save_histograms(self):
        original_path = self.original_image_path.get()
        tampered_path = self.tampered_image_path.get()

        if not os.path.exists(original_path) or not os.path.exists(tampered_path):
            messagebox.showerror("Error", "Image file not found.")
            return

        _, original_histogram, tampered_histogram = detect_image_forgery(original_path, tampered_path, self.ssim_threshold.get())

        # Save histograms to files
        self.save_histogram_to_file(original_histogram, "Original_Histogram.png")
        self.save_histogram_to_file(tampered_histogram, "Tampered_Histogram.png")

        messagebox.showinfo("Histograms Saved", "Histograms saved successfully.")

    def save_histogram_to_file(self, histogram, filename):
        plt.figure(self.original_histogram_figure.number)
        plt.bar(range(len(histogram)), histogram, color='blue', alpha=0.7)
        plt.title("Histogram")
        plt.xlabel("Pixel Value")
        plt.ylabel("Frequency")
        plt.savefig(filename)
        plt.clf()

    def display_histogram(self, histogram, figure, title, color, subplot_position):
        plt.figure(figure.number)
        plt.bar(range(len(histogram)), histogram, color=color, alpha=0.7)
        plt.title(title)
        plt.xlabel('Pixel Intensity')
        plt.ylabel('Frequency')

        # Display histogram in a new window
        histogram_window = tk.Toplevel(self.root)
        histogram_window.title(title)

        # Create a FigureCanvasTkAgg instance
        figure_canvas = FigureCanvasTkAgg(figure, master=histogram_window)
        figure_canvas.draw()
        figure_canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

        # Add navigation toolbar
        toolbar = NavigationToolbar2Tk(figure_canvas, histogram_window)
        toolbar.update()
        figure_canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

    def display_image_preview(self, image_path, preview_label):
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = cv2.resize(image, (150, 150))
        photo = tk.PhotoImage(data=cv2.imencode('.png', image)[1].tostring())
        preview_label.configure(image=photo)
        preview_label.image = photo

def calculate_md5(image_path):
    # Open image file
    with open(image_path, 'rb') as f:
        # Read the content of the file
        content = f.read()
        # Calculate MD5 hash
        md5_hash = hashlib.md5(content).hexdigest()
    return md5_hash

def image_similarity(img1, img2):
    # Compute structural similarity index
    ssim = cv2.compare_ssim(img1, img2)
    return ssim

def detect_image_forgery(original_path, tampered_path, ssim_threshold):
    # Read images
    original_img = cv2.imread(original_path)
    tampered_img = cv2.imread(tampered_path)

    # Resize images to the same dimensions for SSIM comparison
    original_img = cv2.resize(original_img, (256, 256))
    tampered_img = cv2.resize(tampered_img, (256, 256))

    # Calculate MD5 hash for both images
    original_md5 = calculate_md5(original_path)
    tampered_md5 = calculate_md5(tampered_path)

    # Compare MD5 hashes
    if original_md5 != tampered_md5:
        result = "MD5 Hash Mismatch: The images are different."
        return result, [], []

    result = "MD5 Hash Match: The images may be similar."

    # Calculate histograms
    original_histogram = cv2.calcHist([original_img], [0], None, [256], [0, 256]).ravel()
    tampered_histogram = cv2.calcHist([tampered_img], [0], None, [256], [0, 256]).ravel()

    # Compare structural similarity using SSIM
    ssim_score = image_similarity(original_img, tampered_img)

    if ssim_score < ssim_threshold:
        result += f"\nImage similarity score: {ssim_score}\nPossible forgery detected."
    else:
        result += f"\nImage similarity score: {ssim_score}\nImages are likely similar."

    return result, original_histogram, tampered_histogram

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageForgeryDetectorGUI(root)
    root.mainloop()




